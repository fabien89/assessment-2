<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>


      <div class="insidecontent">
          <div class="articleBox">
      <article class="article" id="post-<?php the_ID(); ?>"  <?php post_class(); ?>>
          
          <div class="thumbimage">
	<?php
		// Post thumbnail.
		the_post_thumbnail('medium');
	?>
	</div>

	<header class="Atittle">
		<?php
		if ( is_single() ) :
			the_title( '<h1 class="Atittle">', '</h1>' );
			else :
				the_title( sprintf( '<h2 class="Atittle""><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
			endif;
			?>
	</header><!-- .entry-header -->

	<div class="Aparagraph">
		<?php
		if ( is_single() ) :
			the_content();
			else :
			/* translators: %s: Name of current post */
			the_excerpt(
			sprintf(
				__( 'Continue reading...<span class="screen-reader-text"> "%s"</span>', 'fabpage' )
			)
		);

			endif;
			?>
	</div><!-- .entry-content -->

	

	<footer class="postInfo">
	    <div class="Info"><h4> Author: </h4><span> </span><p><?php the_author(); ?> </p></div>
	    <div class="Info"><h4> Posted: </h4><p><?php the_time('jS F Y') ?> </p></div>
	</footer><!-- .entry-footer -->

</article>
</div>
</div>