
<head>

	<meta charset="UFT-8">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" type="text/css" href="http://127.0.0.1:10080/wordpress/wp-content/themes/fabpage/style.css">
    <title>articles post</title>

</head>