
<div class="sideBar">
        <div class="barContent">
          <div class="artsideBar">

            <div class="articleBoxBar">
              <div class="section sectionbar">
                <h1> Articles </h1>
              </div>
              <article class="zipArt article" >
                 <?php
                 //the loop.
                  	while ( have_posts() ) :
				    the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
		            if ( is_single() ) :
		        	the_title( '<h1 class="Atittle">', '</h1>' );
		        	else :
		    		the_title( sprintf( '<h2 class="Atittle""><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
		        	endif;
			    	// End the loop.
		    	endwhile;
			?>
                  
              </article>

            </div>
          </div>

        </div>
      
 

</div>