<!DOCTYPE html>
  <html lang="en" dir="ltr">


<?php include "header.php" ?>

<body >
<?php include "menu.php" ?>
<div class="content">
    <div class="Aboutcont">
<div class="articleBox ">
    
<article  class="article Aboutcont">
    
    <h2 class="Abouttittle">About this site</h2>
    <p class="Aboutparagraph">
    This site is about to inform and share information of the web, how it works, and explained in an understandable way for you. In addition, you may find useful information of the parts of the internet, the components of the web and the many process that happened in just few seconds that bring you the information that you look for.
<br>
<br>
I am Fabian born in South America 29 years ago. Passionate for design, and I mean any kind of the sign. I found interaction design, interested for this modern era, in where the technology is use on everything.
 Most of the content you will get on this site, had been written by me. I am a student of interaction design, and because of it, I need to understand how the web works. Also I am interested for learning this interface languages that are in use in everywhere.
<br><br>
This web it is also part of an assessment, mostly to practice and learn other web languages, in this case PHP. Which is a language that works with temples and useful for show on the web. PHP is a language with many advantages and when you have lots of information to prepare for a visualization on the web, PHP and its temples make it easy to organize in articles and easy to store them.
Many webs that carry information use this language, as an example, the blogs. Where people share comment and discuss about topics. And it is useful to learn how those webs works as part of the user experience.

    </p>
    
</article>
</div>
    </div>
</div>
<?php include "footer.php" ?>
</body>
</html>