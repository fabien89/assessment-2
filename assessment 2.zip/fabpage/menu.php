

<div class="menu">
    <ul>
        <li>
            <a href="http://127.0.0.1:10080/wordpress/" >Home</a>
            
            <a href="http://127.0.0.1:10080/wordpress/wp-content/themes/fabpage/About.php" >About</a>
            
            <a href="http://127.0.0.1:10080/wordpress/wp-content/themes/fabpage/Articles.php">Articles</a>
        </li>
    </ul>
    
</div>